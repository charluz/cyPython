# tilted-image-correction
# This is a project uses OpenCV perspective transformation to correct tilted images.

* prerequisifte : Visual Studio 2015 or higher vision, OpenCV 3.4.1 or higher vision.
`You need to config OpenCV with Visual Studio`

